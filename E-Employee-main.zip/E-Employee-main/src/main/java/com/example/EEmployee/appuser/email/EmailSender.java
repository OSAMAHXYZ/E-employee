package com.example.EEmployee.appuser.email;

public interface EmailSender {
    void sendEmail(String to , String email);
}
