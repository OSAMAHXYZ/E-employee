package com.example.EEmployee.appuser.collection;

public enum AppUserRole {
    USER,
    ADMIN
}
