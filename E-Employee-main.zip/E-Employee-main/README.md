# E-Employee
E-Employee is a secure Java desktop application where you can 
* Add  Employees
* Delete Employees
* Change Employee' Information
* Search For Employe
# Tools
* MongoDB:MongoDB is NoSQL database which provides a convenient way to store data as JSON formal Along with fast read and writing.
* Java Swing: For UI
* Spring Boot: For API 
* Spring Security: For Implementing Authentication

